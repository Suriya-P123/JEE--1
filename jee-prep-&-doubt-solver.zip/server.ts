import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Set payload limit high for photo/voice uploads
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Lazy initializer for Gemini client to prevent crash on startup if key is missing
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not set. Please add it in the Secrets panel in AI Studio.");
    }
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiInstance;
}

// API endpoint for doubt resolution
app.post("/api/doubt", async (req, res) => {
  try {
    const { text, image, voice, subject, chapter } = req.body;
    const ai = getGeminiClient();

    const parts: any[] = [];

    // Construct a rich system context
    const systemPrompt = `You are "JEE Guru", an elite Joint Entrance Examination (JEE Main & Advanced) academic mentor and expert doubt-solving tutor in India. 
You are highly skilled in Physics, Chemistry, and Mathematics. Your style is highly educational, clear, structured, encouraging, and colorful.
Explain the concepts, write step-by-step mathematical derivations, and provide clear diagrams/ASCII art if necessary.
For the doubt:
- Subject: ${subject || "General"}
- Chapter: ${chapter || "General"}

Always follow these rules in your response:
1. Provide the core concept first in a clear "💡 Core Concept" section.
2. Give a step-by-step mathematical/analytical derivation or breakdown in "📝 Step-by-Step Solution".
3. List 1-2 similar JEE-level practice problems with brief answers in "🚀 Similar JEE Problems".
4. Highlight "⚠️ Common Student Mistakes" for this topic.
5. Keep the explanation engaging, colorful (using emojis and bold titles), and highly organized.`;

    if (text) {
      parts.push({ text: `Student Question:\n${text}` });
    } else {
      parts.push({ text: "Student uploaded a multimodal doubt without explicit text prompt. Solve the uploaded question step-by-step." });
    }

    if (image && image.data && image.mimeType) {
      parts.push({
        inlineData: {
          mimeType: image.mimeType,
          data: image.data,
        }
      });
    }

    if (voice && voice.data && voice.mimeType) {
      parts.push({
        inlineData: {
          mimeType: voice.mimeType,
          data: voice.data,
        }
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts },
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.2,
      }
    });

    res.json({
      success: true,
      solution: response.text,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("Doubt solving error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to process doubt",
    });
  }
});

// Serve Vite dev server or static dist
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Mounted Vite middleware in development mode");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving static files in production mode");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
