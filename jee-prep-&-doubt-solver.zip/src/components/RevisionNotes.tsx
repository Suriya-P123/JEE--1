import React, { useState } from "react";
import { Chapter, SubjectType } from "../types";
import { BookOpen, Download, HelpCircle, Sparkles, Printer } from "lucide-react";

interface RevisionNotesProps {
  chapters: Chapter[];
  selectedSubject: SubjectType;
}

export default function RevisionNotes({ chapters, selectedSubject }: RevisionNotesProps) {
  const [selectedChapterId, setSelectedChapterId] = useState<string | null>(null);

  const filteredChapters = chapters.filter((c) => c.subject === selectedSubject);
  const activeChapter =
    filteredChapters.find((c) => c.id === selectedChapterId) || filteredChapters[0];

  React.useEffect(() => {
    if (filteredChapters.length > 0 && (!selectedChapterId || !filteredChapters.some(c => c.id === selectedChapterId))) {
      setSelectedChapterId(filteredChapters[0].id);
    }
  }, [selectedSubject, filteredChapters]);

  const downloadNotes = (chapter: Chapter) => {
    const title = `=== JEE REVISION NOTES: ${chapter.name.toUpperCase()} ===\n`;
    const subjectLine = `Subject: ${chapter.subject.toUpperCase()}\n`;
    const line = "==================================================\n\n";
    const body = chapter.notes.map((note, index) => `${index + 1}. ${note.replace(/📌\s*/, "")}`).join("\n\n");
    const footer = "\n\nDownloaded from JEE Prep & Doubt Solver Portal. Boost your preparation! 🚀";
    
    const content = title + subjectLine + line + body + footer;
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `JEE_Notes_${chapter.name.replace(/\s+/g, "_")}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const printNotes = () => {
    window.print();
  };

  if (!activeChapter) {
    return (
      <div className="text-center p-8 text-slate-400">
        No notes found for this subject.
      </div>
    );
  }

  const subjectColorMap = {
    physics: {
      accent: "text-cyan-400 border-cyan-500/20 bg-cyan-500/10",
      btn: "bg-gradient-to-r from-cyan-400 to-cyan-500 hover:from-cyan-300 hover:to-cyan-450 text-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.3)]",
      pill: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
    },
    chemistry: {
      accent: "text-amber-400 border-amber-500/20 bg-amber-500/10",
      btn: "bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-450 text-slate-950 shadow-[0_0_12px_rgba(245,158,11,0.3)]",
      pill: "bg-amber-500/10 text-amber-400 border-amber-500/20"
    },
    maths: {
      accent: "text-emerald-400 border-emerald-500/20 bg-emerald-500/10",
      btn: "bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-300 hover:to-emerald-450 text-slate-950 shadow-[0_0_12px_rgba(16,185,129,0.3)]",
      pill: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
    }
  };

  const colors = subjectColorMap[selectedSubject] || subjectColorMap.physics;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Sidebar - Chapter Selection */}
      <div className="lg:col-span-1 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4 flex flex-col gap-2">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider px-2 mb-2">
          Chapters
        </h3>
        {filteredChapters.map((ch) => (
          <button
            key={ch.id}
            id={`note-ch-btn-${ch.id}`}
            onClick={() => setSelectedChapterId(ch.id)}
            className={`w-full text-left p-3 rounded-xl transition duration-200 text-sm flex items-start gap-2 border ${
              activeChapter.id === ch.id
                ? "bg-white/10 border-white/10 text-white font-medium"
                : "border-transparent text-slate-400 hover:bg-white/5 hover:text-slate-200"
            }`}
          >
            <BookOpen className={`w-4 h-4 mt-0.5 shrink-0 ${activeChapter.id === ch.id ? colors.accent.split(" ")[0] : ""}`} />
            <span>{ch.name}</span>
          </button>
        ))}
      </div>

      {/* Main Content - Revision Sheet */}
      <div className="lg:col-span-3 flex flex-col gap-4">
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 md:p-8 relative overflow-hidden flex flex-col gap-6 print:bg-white print:text-black print:border-none print:shadow-none">
          {/* Decorative Glow */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -mr-32 -mt-32 pointer-events-none"></div>

          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6 print:border-slate-300">
            <div>
              <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider mb-2 border ${colors.pill}`}>
                {selectedSubject} Cheat Sheet
              </span>
              <h2 className="text-2xl font-bold text-white tracking-tight print:text-slate-900">
                {activeChapter.name}
              </h2>
              <p className="text-sm text-slate-400 mt-1 print:text-slate-600">
                High-yield formulas, core principles, and quick-revision snippets.
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-2 shrink-0 print:hidden">
              <button
                id="btn-print-notes"
                onClick={printNotes}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 hover:text-white transition duration-200 text-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Print</span>
              </button>
              <button
                id="btn-download-notes"
                onClick={() => downloadNotes(activeChapter)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition duration-200 text-sm shadow-lg ${colors.btn}`}
              >
                <Download className="w-4 h-4" />
                <span>Download TXT</span>
              </button>
            </div>
          </div>

          {/* Notes Body */}
          <div className="flex flex-col gap-4">
            {activeChapter.notes.map((note, index) => {
              // Highlight code/math parts
              const formattedNote = note.replace(/📌\s*/, "");
              const parts = formattedNote.split(/(\[.*?\])/g);

              return (
                <div
                  key={index}
                  className="p-5 rounded-xl bg-white/5 border border-white/10 flex items-start gap-4 transition duration-200 hover:bg-white/10 hover:border-white/20 print:bg-slate-100 print:text-black print:border-slate-300"
                >
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm shrink-0 border ${colors.accent}`}>
                    {index + 1}
                  </span>
                  <div className="text-slate-300 leading-relaxed text-sm md:text-base print:text-slate-800">
                    {parts.map((part, pIdx) => {
                      if (part.startsWith("[") && part.endsWith("]")) {
                        return (
                          <span
                            key={pIdx}
                            className="bg-white/10 text-slate-300 px-1.5 py-0.5 rounded text-xs font-mono border border-white/10 ml-1 inline-block print:bg-slate-200 print:text-slate-800 print:border-slate-400"
                          >
                            {part.slice(1, -1)}
                          </span>
                        );
                      }
                      return <span key={pIdx}>{part}</span>;
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Pro Tip Box */}
          <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-4 flex items-start gap-3 mt-2 print:hidden">
            <Sparkles className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-indigo-300">
                JEE Guru Quick Tip
              </h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                Formulas are most powerful when you understand the boundary conditions. Always review where the formula *fails* (e.g. Newton's mechanics near the speed of light, or ideal gases at ultra-high pressures).
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
