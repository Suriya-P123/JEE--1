import React, { useState, useEffect } from "react";
import { Chapter, Question } from "../types";
import { Award, CheckCircle, AlertTriangle, ArrowRight, Play, Timer, RotateCcw, HelpCircle, XCircle } from "lucide-react";

interface PracticeTestProps {
  chapters: Chapter[];
  selectedSubject: string;
  onTestComplete: (chapterId: string, score: number, total: number) => void;
}

export default function PracticeTest({ chapters, selectedSubject, onTestComplete }: PracticeTestProps) {
  const filteredChapters = chapters.filter((c) => c.subject === selectedSubject);
  const [selectedChapterId, setSelectedChapterId] = useState<string | null>(null);
  
  // Test execution state
  const [testActive, setTestActive] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [answers, setAnswers] = useState<{ [key: string]: number }>({}); // { questionId: selectedIndex }
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes for the chapter test
  const [testFinished, setTestFinished] = useState(false);

  useEffect(() => {
    if (filteredChapters.length > 0 && !selectedChapterId) {
      setSelectedChapterId(filteredChapters[0].id);
    }
  }, [selectedSubject, filteredChapters]);

  // Timer Effect
  useEffect(() => {
    let timer: any;
    if (testActive && !testFinished && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            finishTest(true); // Auto-finish when timer reaches zero
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [testActive, testFinished, timeLeft]);

  const startTest = () => {
    const activeChapter = chapters.find((c) => c.id === selectedChapterId);
    if (!activeChapter || activeChapter.questions.length === 0) return;

    setQuestions(activeChapter.questions);
    setCurrentQuestionIdx(0);
    setSelectedOption(null);
    setSubmitted(false);
    setAnswers({});
    setTimeLeft(300);
    setTestFinished(false);
    setTestActive(true);
  };

  const selectOption = (optionIndex: number) => {
    if (submitted) return;
    setSelectedOption(optionIndex);
  };

  const submitAnswer = () => {
    if (selectedOption === null || submitted) return;
    
    const currentQuestion = questions[currentQuestionIdx];
    setAnswers({ ...answers, [currentQuestion.id]: selectedOption });
    setSubmitted(true);
  };

  const nextQuestion = () => {
    if (currentQuestionIdx < questions.length - 1) {
      setCurrentQuestionIdx((prev) => prev + 1);
      const nextQId = questions[currentQuestionIdx + 1].id;
      setSelectedOption(answers[nextQId] !== undefined ? answers[nextQId] : null);
      setSubmitted(answers[nextQId] !== undefined);
    } else {
      finishTest(false);
    }
  };

  const finishTest = (timeOut: boolean = false) => {
    setTestFinished(true);
    setTestActive(false);

    // Calculate score
    let correctCount = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) {
        correctCount++;
      }
    });

    if (selectedChapterId) {
      onTestComplete(selectedChapterId, correctCount, questions.length);
    }
  };

  const activeChapter = chapters.find((c) => c.id === selectedChapterId);

  // Formatting minutes and seconds
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (!activeChapter) {
    return (
      <div className="text-center p-8 text-slate-400">
        No chapters available to test.
      </div>
    );
  }

  // Chapter Selection Page
  if (!testActive && !testFinished) {
    return (
      <div className="max-w-3xl mx-auto bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 md:p-8 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-48 h-48 bg-violet-500/10 rounded-full blur-3xl -ml-24 -mt-24 pointer-events-none"></div>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-white/5 text-violet-400 rounded-2xl border border-white/10">
            <Timer className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">JEE Chapter Practice Mock</h2>
            <p className="text-sm text-slate-400 mt-0.5">
              Reinforce concepts with instant evaluation mock tests.
            </p>
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-2xl p-5 mb-8">
          <label className="block text-sm font-semibold text-slate-300 mb-3">
            Select Chapter to Begin
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredChapters.map((ch) => (
              <button
                key={ch.id}
                id={`test-chapter-select-${ch.id}`}
                onClick={() => setSelectedChapterId(ch.id)}
                className={`w-full text-left p-4 rounded-xl border transition duration-200 flex flex-col gap-1 ${
                  selectedChapterId === ch.id
                    ? "bg-violet-500/20 border-violet-500/40 text-white"
                    : "bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/10 text-slate-300"
                }`}
              >
                <span className="font-semibold text-sm">{ch.name}</span>
                <span className="text-xs text-slate-400 flex items-center gap-2">
                  <span>{ch.questions.length} JEE Questions</span>
                  {ch.bestScore !== undefined && (
                    <span className="text-emerald-300 font-medium bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                      Best Score: {ch.bestScore}%
                    </span>
                  )}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Test Parameters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-col items-center justify-center text-center">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Format</span>
            <span className="font-bold text-white text-sm mt-1">Single Correct MCQ</span>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-col items-center justify-center text-center">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Time Limit</span>
            <span className="font-bold text-white text-sm mt-1">5 Minutes</span>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex flex-col items-center justify-center text-center">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Marking Scheme</span>
            <span className="font-bold text-emerald-400 text-sm mt-1">+4 Correct, 0 Negative</span>
          </div>
        </div>

        <button
          id="btn-start-test"
          onClick={startTest}
          disabled={activeChapter.questions.length === 0}
          className="w-full bg-gradient-to-r from-violet-500 to-violet-600 hover:from-violet-400 hover:to-violet-500 text-white py-4 px-6 rounded-2xl font-semibold flex items-center justify-center gap-2 transition duration-200 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-violet-500/20"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>Launch Practice Test</span>
        </button>
      </div>
    );
  }

  // Active Test Execution Page
  if (testActive) {
    const currentQ = questions[currentQuestionIdx];

    return (
      <div className="max-w-3xl mx-auto bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 md:p-8 relative">
        {/* Header - Progress & Timer */}
        <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-5 mb-6">
          <div>
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
              Testing: {activeChapter.name}
            </span>
            <h3 className="text-sm font-bold text-white mt-1">
              Question {currentQuestionIdx + 1} of {questions.length}
            </h3>
          </div>

          <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-xl border border-white/10 font-mono text-sm">
            <Timer className={`w-4 h-4 ${timeLeft < 60 ? "text-red-400 animate-pulse" : "text-violet-400"}`} />
            <span className={timeLeft < 60 ? "text-red-400 font-bold" : "text-slate-200"}>
              {formatTime(timeLeft)}
            </span>
          </div>
        </div>

        {/* Question Text */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-5 md:p-6 mb-6">
          <p className="text-slate-200 leading-relaxed text-sm md:text-base">
            {currentQ.text}
          </p>
        </div>

        {/* Options */}
        <div className="flex flex-col gap-3 mb-6">
          {currentQ.options.map((option, idx) => {
            let optionStyle = "border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:border-white/20";
            
            if (submitted) {
              if (idx === currentQ.correctAnswer) {
                optionStyle = "border-emerald-500 bg-emerald-500/20 text-emerald-200 font-medium";
              } else if (idx === selectedOption) {
                optionStyle = "border-red-500 bg-red-500/20 text-red-200";
              }
            } else if (idx === selectedOption) {
              optionStyle = "border-violet-500 bg-violet-500/20 text-violet-200 font-medium";
            }

            return (
              <button
                key={idx}
                id={`option-btn-${idx}`}
                onClick={() => selectOption(idx)}
                disabled={submitted}
                className={`w-full text-left p-4 rounded-xl border transition duration-200 flex items-center gap-3 text-sm leading-relaxed ${optionStyle}`}
              >
                <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs border shrink-0 ${
                  idx === selectedOption
                    ? "bg-violet-500 text-white border-violet-450"
                    : "bg-white/5 border-white/10 text-slate-400"
                }`}>
                  {String.fromCharCode(65 + idx)}
                </span>
                <span>{option}</span>
              </button>
            );
          })}
        </div>

        {/* Answer Explanation Panel */}
        {submitted && (
          <div className="bg-white/5 border border-white/10 rounded-2xl p-5 mb-6 animate-fadeIn">
            <div className="flex items-center gap-2 mb-2">
              {selectedOption === currentQ.correctAnswer ? (
                <div className="flex items-center gap-1.5 text-emerald-400 text-sm font-semibold">
                  <CheckCircle className="w-4 h-4" />
                  <span>Correct! (+4 Marks)</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-red-400 text-sm font-semibold">
                  <XCircle className="w-4 h-4" />
                  <span>Incorrect Response</span>
                </div>
              )}
            </div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Explanation:</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {currentQ.explanation}
            </p>
          </div>
        )}

        {/* Control Footer */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
          {!submitted ? (
            <button
              id="btn-submit-answer"
              onClick={submitAnswer}
              disabled={selectedOption === null}
              className="px-6 py-3 rounded-xl font-bold bg-gradient-to-r from-violet-500 to-violet-600 hover:from-violet-450 hover:to-violet-550 text-white disabled:opacity-50 disabled:cursor-not-allowed transition duration-200 text-sm"
            >
              Submit Answer
            </button>
          ) : (
            <button
              id="btn-next-question"
              onClick={nextQuestion}
              className="px-6 py-3 rounded-xl font-bold bg-white/10 border border-white/10 hover:bg-white/15 text-white flex items-center gap-2 transition duration-200 text-sm"
            >
              <span>{currentQuestionIdx < questions.length - 1 ? "Next Question" : "Complete Test"}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    );
  }

  // Test Finished Scorecard Page
  let correctCount = 0;
  questions.forEach((q) => {
    if (answers[q.id] === q.correctAnswer) {
      correctCount++;
    }
  });
  const scorePercent = Math.round((correctCount / (questions.length || 1)) * 100);

  return (
    <div className="max-w-2xl mx-auto bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-8 relative overflow-hidden text-center">
      <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl -mr-24 -mt-24 pointer-events-none"></div>

      <Award className="w-16 h-16 text-emerald-400 mx-auto mb-4" />

      <h2 className="text-2xl font-bold text-white">Chapter Mock Completed!</h2>
      <p className="text-sm text-slate-400 mt-1 mb-6">
        Great effort! Here is your performance overview for <strong>{activeChapter.name}</strong>.
      </p>

      {/* Circle Score Display */}
      <div className="w-32 h-32 rounded-full border-4 border-white/10 flex flex-col items-center justify-center mx-auto mb-6 relative">
        <span className="text-3xl font-extrabold text-white">{scorePercent}%</span>
        <span className="text-xs text-slate-400 mt-1">Accuracy</span>
        {/* Dynamic green ring representing score */}
        <div className="absolute inset-0 rounded-full border-4 border-emerald-500 opacity-25"></div>
      </div>

      <div className="bg-white/5 border border-white/10 rounded-2xl p-5 mb-8 max-w-md mx-auto grid grid-cols-2 gap-4">
        <div className="text-center">
          <span className="block text-xs text-slate-400 uppercase tracking-wider">Correct</span>
          <span className="font-extrabold text-xl text-emerald-400 mt-1 block">
            {correctCount} / {questions.length}
          </span>
        </div>
        <div className="text-center border-l border-white/10">
          <span className="block text-xs text-slate-400 uppercase tracking-wider">Score</span>
          <span className="font-extrabold text-xl text-white mt-1 block">
            {correctCount * 4} Marks
          </span>
        </div>
      </div>

      <div className="flex gap-3 justify-center">
        <button
          id="btn-retry-test"
          onClick={() => {
            setTestFinished(false);
            setTestActive(false);
          }}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-slate-200 hover:bg-white/10 hover:text-white transition duration-200 text-sm font-semibold"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Try Another Topic</span>
        </button>
        <button
          id="btn-restart-this-test"
          onClick={startTest}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-violet-500 to-violet-600 hover:from-violet-400 hover:to-violet-500 text-white transition duration-200 text-sm font-semibold shadow-lg shadow-violet-500/20"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Retake Mock</span>
        </button>
      </div>
    </div>
  );
}
