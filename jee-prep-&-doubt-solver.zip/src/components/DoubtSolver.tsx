import React, { useState, useRef, useEffect } from "react";
import { DoubtItem, Chapter, SubjectType } from "../types";
import { Send, Image as ImageIcon, Mic, Sparkles, Trash2, HelpCircle, FileText, Check, AlertCircle, X, Volume2 } from "lucide-react";
import Markdown from "react-markdown";

interface DoubtSolverProps {
  chapters: Chapter[];
  selectedSubject: SubjectType;
}

export default function DoubtSolver({ chapters, selectedSubject }: DoubtSolverProps) {
  const [doubtHistory, setDoubtHistory] = useState<DoubtItem[]>([]);
  const [inputText, setInputText] = useState("");
  const [selectedChapterName, setSelectedChapterName] = useState("General");
  const [imageFile, setImageFile] = useState<{ mimeType: string; data: string } | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);
  
  // Voice recording states
  const [isRecording, setIsRecording] = useState(false);
  const [voiceData, setVoiceData] = useState<{ mimeType: string; data: string } | null>(null);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [micBlocked, setMicBlocked] = useState(false);
  
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  const filteredChapters = chapters.filter((c) => c.subject === selectedSubject);

  // Load doubt history from LocalStorage on mount
  useEffect(() => {
    const cached = localStorage.getItem("jee_doubt_history");
    if (cached) {
      try {
        setDoubtHistory(JSON.parse(cached));
      } catch (e) {
        console.error("Failed to parse doubt history", e);
      }
    }
  }, []);

  // Sync doubt history to LocalStorage
  const saveHistory = (updated: DoubtItem[]) => {
    setDoubtHistory(updated);
    localStorage.setItem("jee_doubt_history", JSON.stringify(updated));
  };

  // Recording Timer
  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
      setRecordingSeconds(0);
    }
    return () => clearInterval(timerRef.current);
  }, [isRecording]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setErrorMsg("Please upload an image file (PNG/JPG).");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64String = (reader.result as string).split(",")[1];
      setImageFile({
        mimeType: file.type,
        data: base64String,
      });
      setImagePreviewUrl(reader.result as string);
      setErrorMsg(null);
    };
    reader.readAsDataURL(file);
  };

  const removeSelectedImage = () => {
    setImageFile(null);
    setImagePreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // Real Audio Capture
  const startRecording = async () => {
    setMicBlocked(false);
    audioChunksRef.current = [];
    
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("MediaDevices API not supported in this environment");
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64String = (reader.result as string).split(",")[1];
          setVoiceData({
            mimeType: "audio/webm",
            data: base64String,
          });
        };
        reader.readAsDataURL(audioBlob);
        
        // Stop all tracks to release mic
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setErrorMsg(null);
    } catch (err) {
      console.warn("Microphone access failed. Activating simulation fallback.", err);
      setMicBlocked(true);
      setIsRecording(true); // Still enters visual state to allow simulation
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording && !micBlocked) {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  // Simulated Voice doubts
  const selectSimulatedVoice = (text: string) => {
    setInputText(text);
    setVoiceData({
      mimeType: "audio/mp3",
      data: "SIMULATED_VOICE_DATA",
    });
    setIsRecording(false);
    setMicBlocked(false);
  };

  const handleClearHistory = () => {
    if (confirm("Are you sure you want to clear your doubt solving history?")) {
      saveHistory([]);
    }
  };

  const submitDoubt = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() && !imageFile && !voiceData) {
      setErrorMsg("Please type a question, upload a photo, or record a doubt.");
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);

    const newDoubtId = `doubt-${Date.now()}`;
    const initialDoubt: DoubtItem = {
      id: newDoubtId,
      questionText: inputText,
      imagePreview: imagePreviewUrl || undefined,
      voiceUrl: voiceData ? "Voice Doubt Recorded 🎙️" : undefined,
      subject: selectedSubject.toUpperCase(),
      chapterName: selectedChapterName,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      loading: true,
    };

    const updatedHistory = [initialDoubt, ...doubtHistory];
    saveHistory(updatedHistory);

    try {
      const response = await fetch("/api/doubt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: inputText,
          image: imageFile,
          voice: voiceData,
          subject: selectedSubject,
          chapter: selectedChapterName,
        }),
      });

      const data = await response.json();

      if (data.success) {
        const processed = updatedHistory.map((d) => {
          if (d.id === newDoubtId) {
            return {
              ...d,
              solution: data.solution,
              loading: false,
            };
          }
          return d;
        });
        saveHistory(processed);
        
        // Reset inputs
        setInputText("");
        removeSelectedImage();
        setVoiceData(null);
      } else {
        throw new Error(data.error || "Failed to solve doubt");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Something went wrong. Please check your connection and API key.");
      
      // Remove loading status
      const processed = updatedHistory.map((d) => {
        if (d.id === newDoubtId) {
          return {
            ...d,
            solution: "⚠️ Error: " + (err.message || "Failed to reach JEE Guru solver. Verify your GEMINI_API_KEY in the Secrets panel."),
            loading: false,
          };
        }
        return d;
      });
      saveHistory(processed);
    } finally {
      setIsLoading(false);
    }
  };

  const loadSampleDoubt = (sampleType: "physics" | "chemistry" | "maths") => {
    if (sampleType === "physics") {
      setInputText("A car of mass 1000 kg negotiates a banked curve of radius 50m on a rainy day. If the banking angle is 15° and coefficient of friction is 0.2, find the maximum safe speed without skidding.");
      setSelectedChapterName("Mechanics & Laws of Motion");
      // Simulate an uploaded equation/diagram
      setImagePreviewUrl("https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=400&q=80");
      setImageFile({
        mimeType: "image/jpeg",
        data: "SIMULATED_BASE64_DATA_MOCK",
      });
    } else if (sampleType === "chemistry") {
      setInputText("Draw the molecular orbital energy level diagram for N2 and O2. Compare their bond orders, magnetic properties, and stability based on configuration.");
      setSelectedChapterName("Chemical Bonding & Atomic Structure");
      setImagePreviewUrl("https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?auto=format&fit=crop&w=400&q=80");
      setImageFile({
        mimeType: "image/jpeg",
        data: "SIMULATED_BASE64_DATA_MOCK",
      });
    } else {
      setInputText("Evaluate the limit: lim (x → 0) [ (tan x - sin x) / x³ ] with complete explanation using Taylor series expansion.");
      setSelectedChapterName("Calculus (Limits & Integrals)");
      setImagePreviewUrl("https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=400&q=80");
      setImageFile({
        mimeType: "image/jpeg",
        data: "SIMULATED_BASE64_DATA_MOCK",
      });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Input Form Column */}
      <div className="lg:col-span-1 bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 flex flex-col gap-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none"></div>

        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4 animate-pulse" />
            <span>AI Doubt Solver</span>
          </div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">Ask JEE Guru</h2>
          <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
            Instant academic support. Type your query, upload a textbook picture, or record your voice.
          </p>
        </div>

        {/* Quick presets helper */}
        <div className="p-3 bg-white/5 rounded-xl border border-white/10 flex flex-col gap-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            🚀 Try Sample Doubts
          </span>
          <div className="grid grid-cols-3 gap-1.5">
            <button
              id="btn-preset-phy"
              onClick={() => loadSampleDoubt("physics")}
              className="text-[11px] font-medium bg-cyan-500/10 text-cyan-450 py-1.5 px-2 rounded-lg border border-cyan-500/20 hover:bg-cyan-500/20 transition duration-150"
            >
              Physics
            </button>
            <button
              id="btn-preset-chem"
              onClick={() => loadSampleDoubt("chemistry")}
              className="text-[11px] font-medium bg-amber-500/10 text-amber-450 py-1.5 px-2 rounded-lg border border-amber-500/20 hover:bg-amber-500/20 transition duration-150"
            >
              Chemistry
            </button>
            <button
              id="btn-preset-math"
              onClick={() => loadSampleDoubt("maths")}
              className="text-[11px] font-medium bg-emerald-500/10 text-emerald-450 py-1.5 px-2 rounded-lg border border-emerald-500/20 hover:bg-emerald-500/20 transition duration-150"
            >
              Maths
            </button>
          </div>
        </div>

        <form onSubmit={submitDoubt} className="flex flex-col gap-4">
          {/* Chapter Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Associated Chapter
            </label>
            <select
              id="doubt-chapter-selector"
              value={selectedChapterName}
              onChange={(e) => setSelectedChapterName(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 transition"
            >
              <option value="General" className="bg-slate-900 text-slate-200">General / General Queries</option>
              {filteredChapters.map((ch) => (
                <option key={ch.id} value={ch.name} className="bg-slate-900 text-slate-200">
                  {ch.name}
                </option>
              ))}
            </select>
          </div>

          {/* Question Text Area */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Doubt Description
            </label>
            <textarea
              id="doubt-text-input"
              rows={4}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Explain what you are struggling with or type your problem..."
              className="w-full bg-white/5 border border-white/10 rounded-xl p-3.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition resize-none leading-relaxed"
            />
          </div>

          {/* Photo and Voice Controls */}
          <div className="grid grid-cols-2 gap-3">
            {/* Image Upload Button */}
            <button
              type="button"
              id="btn-trigger-image"
              onClick={() => fileInputRef.current?.click()}
              className={`flex flex-col items-center justify-center p-3 rounded-xl border transition duration-200 text-center cursor-pointer ${
                imagePreviewUrl
                  ? "bg-cyan-500/15 border-cyan-500/30 text-cyan-400"
                  : "bg-white/5 border-white/10 text-slate-400 hover:border-white/20 hover:text-slate-200"
              }`}
            >
              <ImageIcon className="w-5 h-5 mb-1" />
              <span className="text-[10px] font-semibold">
                {imagePreviewUrl ? "Photo Attached" : "Upload Photo"}
              </span>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </button>

            {/* Voice Doubt Button */}
            <button
              type="button"
              id="btn-voice-record"
              onClick={isRecording ? stopRecording : startRecording}
              className={`flex flex-col items-center justify-center p-3 rounded-xl border transition duration-200 text-center ${
                isRecording
                  ? "bg-red-500/20 border-red-500/40 text-red-400 animate-pulse"
                  : voiceData
                  ? "bg-indigo-500/15 border-indigo-500/30 text-indigo-400"
                  : "bg-white/5 border-white/10 text-slate-400 hover:border-white/20 hover:text-slate-200"
              }`}
            >
              <Mic className="w-5 h-5 mb-1" />
              <span className="text-[10px] font-semibold">
                {isRecording ? "Stop Recording" : voiceData ? "Voice Saved" : "Record Doubt"}
              </span>
            </button>
          </div>

          {/* Image preview thumbnail */}
          {imagePreviewUrl && (
            <div className="p-2 bg-white/5 rounded-xl border border-white/10 relative flex items-center gap-3 animate-fadeIn">
              <img
                src={imagePreviewUrl}
                alt="Uploaded doubt"
                className="w-12 h-12 object-cover rounded-lg border border-white/10"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <span className="block text-[10px] font-bold text-slate-300 truncate">Textbook Scan / Photo</span>
                <span className="block text-[9px] text-slate-500">Image attached successfully</span>
              </div>
              <button
                type="button"
                id="btn-remove-image"
                onClick={removeSelectedImage}
                className="p-1 rounded-md bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Recording UI overlay / Simulation options */}
          {isRecording && (
            <div className="p-3.5 bg-white/5 border border-white/10 rounded-xl animate-fadeIn flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                  <span className="text-[11px] font-bold text-slate-200">Recording Voice Doubt...</span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">{recordingSeconds}s</span>
              </div>

              {micBlocked && (
                <div className="flex flex-col gap-2">
                  <div className="flex items-start gap-1.5 text-[10px] text-amber-300 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    <span>Microphone blocked by iframe headers. Simulate an audio query:</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <button
                      type="button"
                      id="btn-voice-sim-1"
                      onClick={() => selectSimulatedVoice("Explain the de Broglie wavelength equation and its derivation for high velocity electrons.")}
                      className="text-left text-[10px] bg-white/5 hover:bg-white/10 text-slate-300 p-2 rounded border border-white/10 truncate"
                    >
                      🗣️ "Explain de Broglie wavelength derivation..."
                    </button>
                    <button
                      type="button"
                      id="btn-voice-sim-2"
                      onClick={() => selectSimulatedVoice("State Le Chatelier's principle and explain the effect of pressure change on equilibrium of N2 + 3H2 <-> 2NH3.")}
                      className="text-left text-[10px] bg-white/5 hover:bg-white/10 text-slate-300 p-2 rounded border border-white/10 truncate"
                    >
                      🗣️ "State Le Chatelier's principle..."
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {voiceData && !isRecording && (
            <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl flex items-center justify-between text-indigo-400 animate-fadeIn">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4" />
                <span className="text-[10px] font-semibold">Voice note processed successfully!</span>
              </div>
              <button
                type="button"
                id="btn-remove-voice"
                onClick={() => setVoiceData(null)}
                className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-red-950/20 border border-red-800/30 text-red-400 text-xs rounded-xl flex items-start gap-2 animate-fadeIn">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            id="btn-submit-doubt"
            disabled={isLoading || (!inputText.trim() && !imageFile && !voiceData)}
            className="w-full bg-gradient-to-r from-cyan-400 to-cyan-500 hover:from-cyan-300 hover:to-cyan-400 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed text-slate-950 py-3.5 px-4 rounded-xl font-bold flex items-center justify-center gap-2 transition duration-200 cursor-pointer text-xs shadow-lg shadow-cyan-500/10"
          >
            <Send className="w-4 h-4" />
            <span>{isLoading ? "Solving Doubt..." : "Submit to JEE Guru"}</span>
          </button>
        </form>
      </div>

      {/* Solutions / Chat History Column */}
      <div className="lg:col-span-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 flex flex-col gap-4 relative overflow-hidden h-[600px]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div>
            <h3 className="font-bold text-white text-sm">Solutions Board</h3>
            <p className="text-[11px] text-slate-400">Your solved doubt archives & formulas derivations.</p>
          </div>
          {doubtHistory.length > 0 && (
            <button
              id="btn-clear-history"
              onClick={handleClearHistory}
              className="flex items-center gap-1 text-slate-500 hover:text-red-400 transition text-[11px] font-semibold"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Board</span>
            </button>
          )}
        </div>

        {/* Board Body */}
        <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-4">
          {doubtHistory.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500">
              <HelpCircle className="w-12 h-12 text-slate-700 mb-2 animate-pulse" />
              <p className="text-sm font-semibold">No Doubts Resolved Yet</p>
              <p className="text-xs text-slate-600 mt-1 max-w-xs">
                Submit a text query, upload a textbook snapshot, or speak your question to see detailed derivations!
              </p>
            </div>
          ) : (
            doubtHistory.map((item) => (
              <div
                key={item.id}
                className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col gap-4 animate-fadeIn"
              >
                {/* Meta details */}
                <div className="flex items-center justify-between text-[10px] font-semibold pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                      {item.subject}
                    </span>
                    <span className="text-slate-400 truncate max-w-[150px]">
                      📂 {item.chapterName}
                    </span>
                  </div>
                  <span className="text-slate-500">{item.timestamp}</span>
                </div>

                {/* Question */}
                <div className="flex flex-col gap-2 bg-white/5 p-3 rounded-xl border border-white/10">
                  <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">
                    Your Question:
                  </span>
                  {item.questionText && (
                    <p className="text-xs text-slate-200 leading-relaxed font-medium">
                      {item.questionText}
                    </p>
                  )}
                  <div className="flex gap-2">
                    {item.imagePreview && (
                      <div className="relative">
                        <img
                          src={item.imagePreview}
                          alt="Doubt attachment"
                          className="w-16 h-16 object-cover rounded-lg border border-white/10"
                          referrerPolicy="no-referrer"
                        />
                        <span className="absolute bottom-1 right-1 bg-white/10 text-[8px] font-bold text-cyan-300 px-1 py-0.2 rounded border border-white/10">
                          Photo
                        </span>
                      </div>
                    )}
                    {item.voiceUrl && (
                      <div className="px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-lg text-[10px] font-semibold flex items-center gap-1 h-8 mt-auto">
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Voice Question Note</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Solution */}
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-extrabold text-cyan-400 uppercase tracking-wider block">
                    👨‍🏫 JEE Guru Solution:
                  </span>

                  {item.loading ? (
                    <div className="flex flex-col gap-2 py-4">
                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <span className="w-3 h-3 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></span>
                        <span>Deducing quantum equations and formulating complete solution step-by-step...</span>
                      </div>
                      <div className="h-4 bg-white/5 rounded animate-pulse w-full"></div>
                      <div className="h-4 bg-white/5 rounded animate-pulse w-[90%]"></div>
                      <div className="h-4 bg-white/5 rounded animate-pulse w-[75%]"></div>
                    </div>
                  ) : (
                    <div className="markdown-body text-slate-300 text-xs md:text-sm leading-relaxed overflow-x-auto select-text">
                      <Markdown>{item.solution}</Markdown>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
