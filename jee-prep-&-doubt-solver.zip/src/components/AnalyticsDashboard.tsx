import React from "react";
import { Chapter } from "../types";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from "recharts";
import { TrendingUp, Target, BookOpen, Star, AlertCircle, RefreshCw, Milestone } from "lucide-react";

interface AnalyticsDashboardProps {
  chapters: Chapter[];
}

export default function AnalyticsDashboard({ chapters }: AnalyticsDashboardProps) {
  // 1. Calculate general statistics
  const totalChapters = chapters.length;
  const masteredCount = chapters.filter((c) => c.status === "mastered").length;
  const completedCount = chapters.filter((c) => c.status === "completed").length;
  const inProgressCount = chapters.filter((c) => c.status === "in-progress" || c.status === "notes-read").length;
  const notStartedCount = chapters.filter((c) => c.status === "not-started").length;

  const physicsChapters = chapters.filter((c) => c.subject === "physics");
  const chemistryChapters = chapters.filter((c) => c.subject === "chemistry");
  const mathsChapters = chapters.filter((c) => c.subject === "maths");

  const calcSubjectProgress = (subjChapters: Chapter[]) => {
    const weights = {
      "not-started": 0,
      "in-progress": 25,
      "notes-read": 50,
      "completed": 75,
      "mastered": 100,
    };
    const totalWeight = subjChapters.reduce((sum, ch) => sum + weights[ch.status], 0);
    return Math.round(totalWeight / (subjChapters.length || 1));
  };

  const physicsProg = calcSubjectProgress(physicsChapters);
  const chemistryProg = calcSubjectProgress(chemistryChapters);
  const mathsProg = calcSubjectProgress(mathsChapters);

  // 2. Prepare data for Recharts Bar Chart
  const subjectProgressData = [
    { name: "Physics", Progress: physicsProg, fill: "#06b6d4" },
    { name: "Chemistry", Progress: chemistryProg, fill: "#f59e0b" },
    { name: "Mathematics", Progress: mathsProg, fill: "#10b981" },
  ];

  // 3. Prepare data for Chapter Accuracies (using the best test scores)
  const accuracyData = chapters
    .filter((c) => c.bestScore !== undefined)
    .map((c) => ({
      chapter: c.name.split(" ")[0] || c.name,
      Score: c.bestScore,
      subject: c.subject.toUpperCase(),
    }));

  // 4. Chapter-wise completion state representation
  const preparationStatusData = [
    { name: "Mastered", value: masteredCount, color: "text-emerald-400 bg-emerald-950/30 border-emerald-800" },
    { name: "Completed", value: completedCount, color: "text-blue-400 bg-blue-950/30 border-blue-800" },
    { name: "In Progress", value: inProgressCount, color: "text-amber-400 bg-amber-950/30 border-amber-800" },
    { name: "Not Started", value: notStartedCount, color: "text-slate-400 bg-slate-950/30 border-slate-800" },
  ];

  // 5. Intelligent Recommendations
  const getInsights = () => {
    const list: string[] = [];
    if (notStartedCount > 0) {
      const firstNotStarted = chapters.find((c) => c.status === "not-started");
      if (firstNotStarted) {
        list.push(`🚀 Start with **${firstNotStarted.name}** (${firstNotStarted.subject.toUpperCase()}) to build early momentum.`);
      }
    }
    if (accuracyData.length > 0) {
      const lowScores = chapters.filter((c) => c.bestScore !== undefined && c.bestScore < 60);
      if (lowScores.length > 0) {
        list.push(`⚠️ Re-revise high-yield notes for **${lowScores[0].name}**. Last mock score was below 60%.`);
      } else {
        list.push("🔥 Excellent! Your concept accuracies are above critical threshold. Keep testing!");
      }
    } else {
      list.push("📋 Take your first Chapter Practice Mock to generate personalized accuracy metrics.");
    }
    if (masteredCount > 2) {
      list.push("🏆 Pro Status: You've achieved JEE Master status in multiple chapters! Keep going.");
    }
    return list;
  };

  const insights = getInsights();

  return (
    <div className="flex flex-col gap-6">
      {/* Dynamic Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 flex items-center gap-4">
          <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium">Physics Prep</span>
            <span className="block text-xl font-extrabold text-white mt-0.5">{physicsProg}%</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 flex items-center gap-4">
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium">Chemistry Prep</span>
            <span className="block text-xl font-extrabold text-white mt-0.5">{chemistryProg}%</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 flex items-center gap-4">
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Star className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium">Mathematics Prep</span>
            <span className="block text-xl font-extrabold text-white mt-0.5">{mathsProg}%</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 flex items-center gap-4">
          <div className="p-3 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Milestone className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium">Mastery Ratio</span>
            <span className="block text-xl font-extrabold text-white mt-0.5">
              {masteredCount} / {totalChapters}
            </span>
          </div>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject Progress Chart */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 flex flex-col gap-4">
          <div>
            <h3 className="text-base font-bold text-white">Subject Preparation Levels</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Overall status of syllabus coverage and test completion weights.
            </p>
          </div>

          <div className="h-64 mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={subjectProgressData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.08)" />
                <XAxis dataKey="name" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} domain={[0, 100]} tickLine={false} />
                <Tooltip
                  cursor={{ fill: "rgba(255, 255, 255, 0.05)" }}
                  contentStyle={{
                    backgroundColor: "rgba(15, 23, 42, 0.9)",
                    border: "1px solid rgba(255,255,255,0.15)",
                    borderRadius: "8px",
                    backdropFilter: "blur(8px)",
                  }}
                  labelStyle={{ color: "#94a3b8", fontWeight: "bold" }}
                />
                <Bar dataKey="Progress" radius={[6, 6, 0, 0]}>
                  {subjectProgressData.map((entry, index) => (
                    <Bar key={`bar-${index}`} dataKey="Progress" fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Accuracy Level Chart */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 flex flex-col gap-4">
          <div>
            <h3 className="text-base font-bold text-white">Chapter Mock Accuracies</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Best scores obtained during chapter-wise simulation tests.
            </p>
          </div>

          <div className="h-64 mt-2 flex items-center justify-center">
            {accuracyData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={accuracyData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <defs>
                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.08)" />
                  <XAxis dataKey="chapter" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} />
                  <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} domain={[0, 100]} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(15, 23, 42, 0.9)",
                      border: "1px solid rgba(255,255,255,0.15)",
                      borderRadius: "8px",
                      backdropFilter: "blur(8px)",
                    }}
                    labelStyle={{ color: "#94a3b8", fontWeight: "bold" }}
                  />
                  <Area type="monotone" dataKey="Score" stroke="#8b5cf6" strokeWidth={2} fillOpacity={1} fill="url(#colorScore)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center p-8 text-slate-500 text-sm flex flex-col items-center gap-2">
                <Target className="w-10 h-10 text-slate-600 mb-1" />
                <span>No test history found.</span>
                <span className="text-xs text-slate-500 max-w-xs">Complete an interactive practice test to generate accuracies graph!</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Chapter Distribution & Recommendation Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Progress Grid */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 lg:col-span-1 flex flex-col gap-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Chapter Syllabus Status</h3>
          <div className="flex flex-col gap-2.5">
            {preparationStatusData.map((item, idx) => {
              // Map old classes to Frosted Glass styles
              let styleStr = "";
              if (item.name === "Mastered") {
                styleStr = "text-emerald-300 bg-emerald-500/10 border-emerald-500/20";
              } else if (item.name === "Completed") {
                styleStr = "text-blue-300 bg-blue-500/10 border-blue-500/20";
              } else if (item.name === "In Progress") {
                styleStr = "text-amber-300 bg-amber-500/10 border-amber-500/20";
              } else {
                styleStr = "text-slate-300 bg-white/5 border-white/10";
              }

              return (
                <div
                  key={idx}
                  className={`p-3 rounded-xl border flex items-center justify-between transition hover:scale-[1.02] ${styleStr}`}
                >
                  <span className="text-sm font-medium">{item.name}</span>
                  <span className="text-sm font-bold">{item.value} Chapters</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Study Insights */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 lg:col-span-2 flex flex-col gap-4">
          <div className="flex items-center gap-2 border-b border-white/10 pb-3">
            <TrendingUp className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Guru Personalised Study Insights</h3>
          </div>

          <div className="flex flex-col gap-3">
            {insights.map((insight, index) => {
              // Simple markdown replacement for **text**
              const formatted = insight.split("**").map((chunk, cIdx) => {
                if (cIdx % 2 === 1) {
                  return <strong key={cIdx} className="text-white font-semibold">{chunk}</strong>;
                }
                return chunk;
              });

              return (
                <div key={index} className="flex items-start gap-3 p-3 bg-white/5 rounded-xl border border-white/10">
                  <span className="mt-0.5 shrink-0">📍</span>
                  <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
                    {formatted}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
