export type SubjectType = "physics" | "chemistry" | "maths";

export type ProgressStatus = "not-started" | "in-progress" | "notes-read" | "completed" | "mastered";

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number; // 0-indexed
  explanation: string;
}

export interface Chapter {
  id: string;
  name: string;
  subject: SubjectType;
  status: ProgressStatus;
  notes: string[]; // Important high-yield revision points or formulas
  questions: Question[]; // Chapter-specific JEE mock questions
  bestScore?: number; // percentage (0 - 100)
  testHistory?: {
    score: number;
    total: number;
    date: string;
  }[];
}

export interface DoubtItem {
  id: string;
  questionText?: string;
  imagePreview?: string;
  voiceUrl?: string;
  solution?: string;
  subject?: string;
  chapterName?: string;
  timestamp: string;
  loading?: boolean;
}

export interface StudentStats {
  physicsProgress: number; // percentage
  chemistryProgress: number; // percentage
  mathsProgress: number; // percentage
  totalTestsTaken: number;
  averageTestScore: number; // percentage
  weeklyActivity: { day: string; hours: number }[];
}
