import { Chapter } from "./types";

export const initialChapters: Chapter[] = [
  // --- PHYSICS ---
  {
    id: "phy-1",
    name: "Mechanics & Laws of Motion",
    subject: "physics",
    status: "not-started",
    notes: [
      "📌 Newton's Second Law: F = dp/dt = m(dv/dt) + v(dm/dt) [Variable mass systems like rockets].",
      "📌 Friction: Static friction f_s ≤ μ_s * N. Kinetic friction f_k = μ_k * N. Kinetic friction is always independent of contact area.",
      "📌 Centripetal Acceleration: a_c = v²/r = ω²r. In non-uniform circular motion, net acceleration is √(a_c² + a_t²).",
      "📌 Conservation of Momentum: If ∑F_ext = 0, then P_initial = P_final. Applicable in all types of collisions (elastic and inelastic).",
      "📌 Coefficient of Restitution (e): e = (Relative speed of separation) / (Relative speed of approach) = (v₂ - v₁) / (u₁ - u₂)."
    ],
    questions: [
      {
        id: "phy-1-q1",
        text: "A block of mass 2 kg is placed on a rough horizontal surface with coefficient of static friction μ_s = 0.5. A horizontal force of 6 N is applied to the block. What is the frictional force acting on the block? (Take g = 10 m/s²)",
        options: [
          "10 N",
          "6 N",
          "5 N",
          "0 N"
        ],
        correctAnswer: 1,
        explanation: "The maximum static frictional force possible is f_s_max = μ_s * N = μ_s * m * g = 0.5 * 2 * 10 = 10 N. Since the applied horizontal force (6 N) is less than the maximum static friction (10 N), the block does not move. Therefore, static friction adjusts itself to exactly balance the applied force, resulting in a frictional force of 6 N."
      },
      {
        id: "phy-1-q2",
        text: "A particle of mass m moves in a circle of radius r with a constant angular velocity ω. What is the work done by the centripetal force during one complete revolution?",
        options: [
          "2π m ω² r²",
          "π m ω² r²",
          "0",
          "1/2 m ω² r²"
        ],
        correctAnswer: 2,
        explanation: "Centripetal force always acts towards the center of the circle, which is perpendicular to the displacement vector at any given instant. Work done W = ∫ F · ds = ∫ F * ds * cos(90°) = 0. Thus, centripetal force does zero work in any circular path."
      }
    ]
  },
  {
    id: "phy-2",
    name: "Electrostatics & Capacitance",
    subject: "physics",
    status: "not-started",
    notes: [
      "📌 Coulomb's Law: F = (1 / 4πε₀) * (q₁q₂ / r²). Electric field of point charge: E = (1 / 4πε₀) * (q / r²).",
      "📌 Gauss's Law: ∮ E · dA = Q_enclosed / ε₀. Extremely useful for finding fields of symmetric distributions.",
      "📌 Electrostatic Potential Energy: U = (1 / 4πε₀) * (q₁q₂ / r). Electric potential: V = U/q = (1 / 4πε₀) * (q / r).",
      "📌 Capacitance of parallel plate: C = K * ε₀ * A / d, where K is the dielectric constant.",
      "📌 Energy stored in capacitor: U = 1/2 * C * V² = Q² / (2C) = 1/2 * Q * V."
    ],
    questions: [
      {
        id: "phy-2-q1",
        text: "Two identical conducting spheres A and B carry charges +Q and -3Q respectively. They are brought in contact and then separated to their original positions. What is the ratio of final force to initial force between them?",
        options: [
          "1 : 3",
          "3 : 1",
          "1 : 2",
          "4 : 3"
        ],
        correctAnswer: 0,
        explanation: "Initially, force F₁ ∝ |Q * (-3Q)| / r² = 3Q²/r². When brought in contact, the total charge (+Q - 3Q = -2Q) is equally shared. Each sphere gets charge -Q. The final force F₂ ∝ |(-Q) * (-Q)| / r² = Q²/r². Therefore, the ratio F₂ : F₁ = (Q²/r²) / (3Q²/r²) = 1 : 3."
      },
      {
        id: "phy-2-q2",
        text: "A parallel plate capacitor is charged and then disconnected from the battery. If the separation between the plates is doubled, what happens to the energy stored and the potential difference?",
        options: [
          "Energy doubles, Potential doubles",
          "Energy remains same, Potential remains same",
          "Energy is halved, Potential is halved",
          "Energy doubles, Potential remains same"
        ],
        correctAnswer: 0,
        explanation: "Since the battery is disconnected, the charge Q remains constant. Capacitance C = ε₀A/d. When separation d is doubled, capacitance is halved (C' = C/2). Energy stored U = Q² / (2C). With C' = C/2, the energy stored doubles (U' = 2U). Potential difference V = Q/C. Since C is halved, V doubles (V' = 2V)."
      }
    ]
  },
  {
    id: "phy-3",
    name: "Modern Physics & Optics",
    subject: "physics",
    status: "not-started",
    notes: [
      "📌 Einstein's Photoelectric Equation: eV₀ = hν - φ = hc/λ - hc/λ₀, where V₀ is stopping potential, φ is work function.",
      "📌 de Broglie Wavelength: λ = h/p = h / √(2mK) = h / √(2mqV). For electrons, λ ≈ 12.27 / √V Å.",
      "📌 Bohr's Orbit Quantization: mvr = n * (h/2π). Orbit energy E_n = -13.6 * Z² / n² eV.",
      "📌 Radioactive Decay Law: N(t) = N₀ * e^(-λt). Half-life T_1/2 = ln(2)/λ ≈ 0.693/λ.",
      "📌 Snell's Law: μ₁ sin(i) = μ₂ sin(r). Lens Maker's Formula: 1/f = (μ_rel - 1) * (1/R₁ - 1/R₂)."
    ],
    questions: [
      {
        id: "phy-3-q1",
        text: "The work function of a metal surface is 4.0 eV. For photoelectric emission, what is the maximum wavelength of the incident radiation?",
        options: [
          "620 nm",
          "310 nm",
          "155 nm",
          "410 nm"
        ],
        correctAnswer: 1,
        explanation: "Threshold wavelength λ₀ = hc / φ. Since hc ≈ 1240 eV·nm, we have λ₀ = 1240 eV·nm / 4.0 eV = 310 nm. Light with a wavelength greater than this threshold will not have enough energy to eject electrons."
      },
      {
        id: "phy-3-q2",
        text: "If an electron in a hydrogen atom jumps from the third orbit (n=3) to the second orbit (n=2), what spectral series does it belong to and what is its energy change?",
        options: [
          "Lyman series, energy release of 10.2 eV",
          "Balmer series, energy release of 1.89 eV",
          "Balmer series, energy gain of 1.89 eV",
          "Paschen series, energy release of 1.51 eV"
        ],
        correctAnswer: 1,
        explanation: "Transitions ending at n=2 belong to the Balmer series (visible spectrum). Energy of hydrogen orbits are E_n = -13.6 / n² eV. So, E₂ = -13.6 / 4 = -3.4 eV, and E₃ = -13.6 / 9 = -1.51 eV. Energy released ΔE = E₃ - E₂ = -1.51 - (-3.4) = 1.89 eV. Since n goes from higher to lower orbit, it releases energy."
      }
    ]
  },

  // --- CHEMISTRY ---
  {
    id: "chem-1",
    name: "Chemical Bonding & Atomic Structure",
    subject: "chemistry",
    status: "not-started",
    notes: [
      "📌 Schrödinger Wave Equation: ĤΨ = EΨ. Quantum numbers: Principle (n), Azimuthal (l), Magnetic (m), Spin (s).",
      "📌 VSEPR Theory: Predicts molecular geometries. Double/triple bonds occupy more space than single bonds. Lone pair-Lone pair repulsion > Lone pair-Bond pair > Bond pair-Bond pair.",
      "📌 Hybridization: sp (Linear, 180°), sp² (Trigonal Planar, 120°), sp³ (Tetrahedral, 109.5°), sp³d (Trigonal Bipyramidal), sp³d² (Octahedral).",
      "📌 Molecular Orbital Theory (MOT): Bond Order = 0.5 * (N_b - N_a). If Bond Order > 0, the species exists. Diamagnetic (all electrons paired), Paramagnetic (unpaired electrons)."
    ],
    questions: [
      {
        id: "chem-1-q1",
        text: "Using Molecular Orbital Theory, identify which of the following diatomic species is paramagnetic and has a bond order of 2?",
        options: [
          "O₂",
          "N₂",
          "C₂",
          "O₂²⁻"
        ],
        correctAnswer: 0,
        explanation: "According to MOT, O₂ (16 electrons) has the electronic configuration: σ1s² σ*1s² σ2s² σ*2s² σ2p_z² (π2p_x² = π2p_y²) (π*2p_x¹ = π*2p_y¹). It has 2 unpaired electrons in antibonding π* orbitals, making it paramagnetic. Its bond order is (10 - 6)/2 = 2."
      },
      {
        id: "chem-1-q2",
        text: "What is the hybridization and molecular shape of SF₄ (Sulfur tetrafluoride) according to VSEPR theory?",
        options: [
          "sp³d, Seesaw",
          "sp³, Tetrahedral",
          "sp³d², Square Planar",
          "sp³d, Tetrahedral"
        ],
        correctAnswer: 0,
        explanation: "Sulfur has 6 valence electrons. In SF₄, it forms 4 single bonds with Fluorine, leaving 1 lone pair. Total steric number = 4 (bonds) + 1 (lone pair) = 5. Hence, hybridization is sp³d. The geometry is trigonal bipyramidal, but due to 1 lone pair in the equatorial position, the molecular shape is Seesaw."
      }
    ]
  },
  {
    id: "chem-2",
    name: "Thermodynamics & Equilibrium",
    subject: "chemistry",
    status: "not-started",
    notes: [
      "📌 First Law of Thermodynamics: ΔU = q + w. In chemistry, w = -P_ext * ΔV for expansion.",
      "📌 Gibbs Free Energy: ΔG = ΔH - TΔS. For spontaneous processes at constant T & P, ΔG < 0. At equilibrium, ΔG = 0.",
      "📌 Relationship with K: ΔG° = -R * T * ln(K_eq) = -2.303 * R * T * log(K_eq).",
      "📌 Le Chatelier's Principle: If stress is applied to a system at equilibrium, the system shifts to relieve that stress.",
      "📌 pH and Buffer Solutions: pH = pK_a + log([Salt]/[Acid]) [Henderson-Hasselbalch equation for acidic buffers]."
    ],
    questions: [
      {
        id: "chem-2-q1",
        text: "For a certain reaction, ΔH = -50 kJ/mol and ΔS = -100 J/(K·mol). At what temperature range will this reaction become non-spontaneous?",
        options: [
          "Below 500 K",
          "Above 500 K",
          "At all temperatures",
          "Above 250 K"
        ],
        correctAnswer: 1,
        explanation: "Spontaneity depends on Gibbs Free Energy: ΔG = ΔH - TΔS. For non-spontaneity, ΔG > 0. Thus, ΔH - TΔS > 0 => -50000 J/mol - T * (-100 J/K·mol) > 0 => 100T > 50000 => T > 500 K. Therefore, above 500 K, the reaction is non-spontaneous."
      },
      {
        id: "chem-2-q2",
        text: "What is the pH of a buffer solution prepared by mixing 0.1 M Acetic acid (CH₃COOH) and 0.2 M Sodium acetate (CH₃COONa)? (Take pK_a of acetic acid = 4.74, and log 2 = 0.3)",
        options: [
          "4.44",
          "5.04",
          "4.74",
          "5.34"
        ],
        correctAnswer: 1,
        explanation: "Using Henderson-Hasselbalch equation: pH = pK_a + log([Salt] / [Acid]) = 4.74 + log(0.2 / 0.1) = 4.74 + log(2) = 4.74 + 0.3 = 5.04."
      }
    ]
  },
  {
    id: "chem-3",
    name: "Organic Chemistry (Carbonyls & Amines)",
    subject: "chemistry",
    status: "not-started",
    notes: [
      "📌 Nucleophilic Addition: Highly characteristic of Aldehydes and Ketones due to polar C=O bond. Reactivity: Aldehydes > Ketones.",
      "📌 Aldol Condensation: Requires carbonyls with at least one α-hydrogen in the presence of dilute base. Forms β-hydroxyaldehyde/ketone.",
      "📌 Cannizzaro Reaction: Self-oxidation/reduction of aldehydes lacking α-hydrogens (e.g., HCHO, C_6H_5CHO) using concentrated NaOH.",
      "📌 Grignard Reagent (R-Mg-X): Strong nucleophile. Reacts with HCHO to give Primary alcohols, with other aldehydes to give Secondary, and with ketones to give Tertiary alcohols."
    ],
    questions: [
      {
        id: "chem-3-q1",
        text: "Which of the following compounds will undergo self-Cannizzaro reaction when heated with concentrated sodium hydroxide solution?",
        options: [
          "Acetaldehyde (CH₃CHO)",
          "Benzaldehyde (C₆H₅CHO)",
          "Acetone (CH₃COCH₃)",
          "Propanal (CH₃CH₂CHO)"
        ],
        correctAnswer: 1,
        explanation: "Cannizzaro reaction is given only by aldehydes that do not contain any α-hydrogen atoms. Benzaldehyde (C₆H₅CHO) has no α-hydrogen, so it undergoes disproportionation (one molecule oxidized to Sodium benzoate, another reduced to Benzyl alcohol). Acetaldehyde, Propanal, and Acetone have α-hydrogens and would undergo Aldol condensation instead."
      },
      {
        id: "chem-3-q2",
        text: "An organic compound 'X' reacts with Grignard reagent CH₃MgBr to form an adduct which on hydrolysis gives 2-propanol. Identify compound 'X'.",
        options: [
          "Formaldehyde (HCHO)",
          "Acetaldehyde (CH₃CHO)",
          "Acetone (CH₃COCH₃)",
          "Ethyl alcohol (C₂H₅OH)"
        ],
        correctAnswer: 1,
        explanation: "Acetaldehyde (CH₃CHO) reacts with methylmagnesium bromide (CH₃MgBr) to yield a secondary alcohol adduct, which upon acidic hydrolysis splits to give propan-2-ol (2-propanol). Formaldehyde would give ethanol (1° alcohol), and Acetone would give 2-methylpropan-2-ol (3° alcohol)."
      }
    ]
  },

  // --- MATHS ---
  {
    id: "math-1",
    name: "Calculus (Limits & Integrals)",
    subject: "maths",
    status: "not-started",
    notes: [
      "📌 L'Hopital's Rule: For 0/0 or ∞/∞ limit forms, lim(x->a) f(x)/g(x) = lim(x->a) f'(x)/g'(x), provided g'(x) ≠ 0.",
      "📌 Leibniz Rule for Integral Differentiation: d/dx [ ∫_(g(x))^(h(x)) f(t) dt ] = f(h(x)) * h'(x) - f(g(x)) * g'(x).",
      "📌 Integration by Parts: ∫ u v dx = u ∫ v dx - ∫ [ u' * (∫ v dx) ] dx. (ILATE rule for sequence choice).",
      "📌 Definite Integral Symmetry: ∫₀^a f(x) dx = ∫₀^a f(a-x) dx (King's Property - highly critical for JEE!).",
      "📌 Integration of Odd/Even: ∫_-a^a f(x) dx = 2 ∫₀^a f(x) dx (if even) or 0 (if odd)."
    ],
    questions: [
      {
        id: "math-1-q1",
        text: "Evaluate the limit: lim (x → 0) [ (e^x - 1 - x) / x² ]",
        options: [
          "1",
          "1/2",
          "0",
          "Does not exist"
        ],
        correctAnswer: 1,
        explanation: "Direct substitution yields 0/0 form. Applying L'Hopital's Rule once: lim (x → 0) [ (e^x - 1) / 2x ]. This is still 0/0 form. Applying L'Hopital's Rule a second time: lim (x → 0) [ e^x / 2 ] = e^0 / 2 = 1/2. Alternatively, using Taylor series of e^x = 1 + x + x²/2! + ..., the terms simplify directly to 1/2."
      },
      {
        id: "math-1-q2",
        text: "Evaluate the definite integral: I = ∫_0^(π/2) [ (sin x) / (sin x + cos x) ] dx",
        options: [
          "π/2",
          "π/4",
          "π",
          "0"
        ],
        correctAnswer: 1,
        explanation: "Applying King's Property (replacing x with π/2 - x): I = ∫_0^(π/2) [ sin(π/2 - x) / (sin(π/2 - x) + cos(π/2 - x)) ] dx = ∫_0^(π/2) [ cos x / (cos x + sin x) ] dx. Adding the two integral equations: 2I = ∫_0^(π/2) [ (sin x + cos x) / (sin x + cos x) ] dx = ∫_0^(π/2) 1 dx = [x]_0^(π/2) = π/2. Therefore, I = π/4."
      }
    ]
  },
  {
    id: "math-2",
    name: "Coordinate Geometry (Conics & Lines)",
    subject: "maths",
    status: "not-started",
    notes: [
      "📌 Straight Lines: Distance between parallel lines y = mx + c₁ and y = mx + c₂ is |c₁ - c₂| / √(1 + m²).",
      "📌 Circles: Equation of tangent to circle x² + y² = r² at point (x₁, y₁) is x*x₁ + y*y₁ = r².",
      "📌 Parabola (y² = 4ax): Parametric form x = at², y = 2at. Focal distance of point P(x, y) is x + a.",
      "📌 Ellipse (x²/a² + y²/b² = 1): Eccentricity e = √(1 - b²/a²) (assuming a > b). Foci are at (±ae, 0).",
      "📌 Hyperbola (x²/a² - y²/b² = 1): Eccentricity e = √(1 + b²/a²). Equations of asymptotes: y = ±(b/a)x."
    ],
    questions: [
      {
        id: "math-2-q1",
        text: "Find the eccentricity of the ellipse whose latus rectum is half of its minor axis.",
        options: [
          "√3 / 2",
          "1 / √2",
          "1 / 2",
          "√2 / 3"
        ],
        correctAnswer: 0,
        explanation: "Let the ellipse equation be x²/a² + y²/b² = 1 (a > b). Length of minor axis is 2b. Length of latus rectum is 2b²/a. Given: 2b²/a = 1/2 * (2b) => 2b²/a = b => 2b/a = 1 => b/a = 1/2. We know eccentricity e = √(1 - b²/a²). Substituting b/a = 1/2: e = √(1 - 1/4) = √3/2."
      },
      {
        id: "math-2-q2",
        text: "What is the condition for the straight line y = mx + c to be a tangent to the parabola y² = 4ax?",
        options: [
          "c = a/m",
          "c = am",
          "c = -am²",
          "c = a²m"
        ],
        correctAnswer: 0,
        explanation: "Substitute y = mx + c into the parabola equation: (mx + c)² = 4ax => m²x² + 2mcx + c² = 4ax => m²x² + (2mc - 4a)x + c² = 0. For the line to be a tangent, this quadratic in x must have equal roots, i.e., discriminant D = 0. Hence (2mc - 4a)² - 4m²c² = 0 => 4m²c² - 16mac + 16a² - 4m²c² = 0 => -16mac + 16a² = 0 => c = a/m."
      }
    ]
  },
  {
    id: "math-3",
    name: "Matrices, Determinants & Algebra",
    subject: "maths",
    status: "not-started",
    notes: [
      "📌 Determinant Properties: |A * B| = |A| * |B|. |k * A| = k^n * |A|, where n is the order of matrix A.",
      "📌 Inverse of a Matrix: A⁻¹ = (1/|A|) * adj(A). System of equations has infinite solutions if Δ = Δ_x = Δ_y = Δ_z = 0.",
      "📌 Quadratic Equations: If α, β are roots of ax² + bx + c = 0, then α+β = -b/a and α*β = c/a.",
      "📌 Complex Numbers: De Moivre's Theorem: (cos θ + i sin θ)^n = cos(nθ) + i sin(nθ) = e^(i * n * θ)."
    ],
    questions: [
      {
        id: "math-3-q1",
        text: "If A is a square matrix of order 3 such that |A| = 5, what is the value of the determinant of its adjoint matrix, |adj(A)|?",
        options: [
          "5",
          "25",
          "125",
          "1"
        ],
        correctAnswer: 1,
        explanation: "For any square matrix A of order n, we have the identity |adj(A)| = |A|^(n-1). Given n = 3 and |A| = 5, we calculate: |adj(A)| = 5^(3-1) = 5² = 25."
      },
      {
        id: "math-3-q2",
        text: "If α and β are the roots of the quadratic equation x² - 5x + 6 = 0, find the quadratic equation whose roots are α+1 and β+1.",
        options: [
          "x² - 7x + 12 = 0",
          "x² - 5x + 12 = 0",
          "x² - 7x + 6 = 0",
          "x² - 6x + 9 = 0"
        ],
        correctAnswer: 0,
        explanation: "For the original equation, α+β = 5 and αβ = 6. The roots are actually 2 and 3. The new roots are 2+1=3 and 3+1=4. The quadratic equation with roots 3 and 4 is given by: x² - (Sum of roots)x + (Product of roots) = 0 => x² - (3+4)x + (3*4) = 0 => x² - 7x + 12 = 0."
      }
    ]
  }
];
