import React, { useState, useEffect } from "react";
import { Chapter, SubjectType, ProgressStatus } from "./types";
import { initialChapters } from "./jeeData";
import RevisionNotes from "./components/RevisionNotes";
import PracticeTest from "./components/PracticeTest";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import DoubtSolver from "./components/DoubtSolver";
import { BookOpen, GraduationCap, Flame, LayoutDashboard, CheckSquare, Sparkles, User, Calendar, Award, Compass, RefreshCw } from "lucide-react";

export default function App() {
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<SubjectType>("physics");
  const [activeTab, setActiveTab] = useState<"syllabus" | "notes" | "test" | "doubt" | "analytics">("syllabus");
  
  // Load chapters with cached progress on mount
  useEffect(() => {
    const cached = localStorage.getItem("jee_chapters_progress");
    if (cached) {
      try {
        const saved = JSON.parse(cached);
        const merged = initialChapters.map((ic) => {
          const match = saved.find((s: any) => s.id === ic.id);
          if (match) {
            return {
              ...ic,
              status: match.status || "not-started",
              bestScore: match.bestScore,
              testHistory: match.testHistory || [],
            };
          }
          return ic;
        });
        setChapters(merged);
      } catch (e) {
        console.error("Failed to parse cached chapters progress", e);
        setChapters(initialChapters);
      }
    } else {
      setChapters(initialChapters);
    }
  }, []);

  // Save progress changes to LocalStorage
  const saveChaptersProgress = (updated: Chapter[]) => {
    setChapters(updated);
    const saveSlice = updated.map((c) => ({
      id: c.id,
      status: c.status,
      bestScore: c.bestScore,
      testHistory: c.testHistory,
    }));
    localStorage.setItem("jee_chapters_progress", JSON.stringify(saveSlice));
  };

  const handleStatusChange = (chapterId: string, newStatus: ProgressStatus) => {
    const updated = chapters.map((c) => {
      if (c.id === chapterId) {
        return { ...c, status: newStatus };
      }
      return c;
    });
    saveChaptersProgress(updated);
  };

  const handleTestComplete = (chapterId: string, correct: number, total: number) => {
    const scorePercent = Math.round((correct / total) * 100);
    const dateStr = new Date().toLocaleDateString();

    const updated = chapters.map((c) => {
      if (c.id === chapterId) {
        const history = c.testHistory || [];
        const newHistory = [...history, { score: correct, total, date: dateStr }];
        const currentBest = c.bestScore || 0;
        const newBest = Math.max(currentBest, scorePercent);
        
        // Auto-advance status if they scored well!
        let newStatus = c.status;
        if (scorePercent >= 80) {
          newStatus = "mastered";
        } else if (scorePercent >= 40) {
          newStatus = "completed";
        }

        return {
          ...c,
          status: newStatus as ProgressStatus,
          bestScore: newBest,
          testHistory: newHistory,
        };
      }
      return c;
    });
    saveChaptersProgress(updated);
  };

  const resetAllProgress = () => {
    if (confirm("Are you sure you want to reset all preparation progress, metrics, and doubt solver history?")) {
      localStorage.removeItem("jee_chapters_progress");
      localStorage.removeItem("jee_doubt_history");
      setChapters(initialChapters.map(c => ({ ...c, status: "not-started", bestScore: undefined, testHistory: [] })));
      alert("All progress reset completed.");
    }
  };

  // UI Theme styling dictionaries based on subject
  const subjectThemes = {
    physics: {
      accent: "text-cyan-400",
      accentBg: "bg-cyan-500",
      border: "border-cyan-500/30",
      hover: "hover:bg-cyan-500/10 hover:text-cyan-400",
      pill: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
      glow: "shadow-[0_0_50px_-12px_rgba(6,182,212,0.15)]",
    },
    chemistry: {
      accent: "text-amber-400",
      accentBg: "bg-amber-500",
      border: "border-amber-500/30",
      hover: "hover:bg-amber-500/10 hover:text-amber-400",
      pill: "bg-amber-500/10 text-amber-400 border-amber-500/20",
      glow: "shadow-[0_0_50px_-12px_rgba(245,158,11,0.15)]",
    },
    maths: {
      accent: "text-emerald-400",
      accentBg: "bg-emerald-500",
      border: "border-emerald-500/30",
      hover: "hover:bg-emerald-500/10 hover:text-emerald-400",
      pill: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
      glow: "shadow-[0_0_50px_-12px_rgba(16,185,129,0.15)]",
    },
  };

  const activeTheme = subjectThemes[selectedSubject] || subjectThemes.physics;

  // Calculate generic statistics
  const completedChaptersCount = chapters.filter(c => c.status === "completed" || c.status === "mastered").length;
  const totalChaptersCount = chapters.length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans relative pb-12 antialiased overflow-x-hidden">
      {/* Immersive Background Gradients */}
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/40 via-purple-900/40 to-slate-950 pointer-events-none z-0"></div>
      <div className="absolute top-[-10%] right-[-10%] w-[450px] h-[450px] bg-blue-500/20 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-[450px] h-[450px] bg-fuchsia-500/20 rounded-full blur-[120px] pointer-events-none z-0"></div>

      {/* Outer wrapper */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 z-10 relative flex flex-col gap-6 pt-6">
        
        {/* TOP META BAR (Countdown & Fast Profile Access) */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/5 backdrop-blur-md border border-white/10 px-5 py-3 rounded-2xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
            <Calendar className="w-4 h-4 text-indigo-400" />
            <span>JEE Main 2027 Countdown:</span>
            <span className="text-white bg-white/10 border border-white/10 px-2 py-0.5 rounded font-mono">
              248 Days Left
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Friendly personalized welcome using Suriya or Scholar */}
            <div className="flex items-center gap-2 text-xs">
              <div className="w-6 h-6 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-indigo-400 font-bold">
                S
              </div>
              <span className="text-slate-300 font-medium">Welcome back, <strong className="text-white">Suriya</strong></span>
            </div>

            <button
              id="btn-reset-data"
              onClick={resetAllProgress}
              className="text-slate-400 hover:text-red-400 transition text-[11px] font-semibold flex items-center gap-1 bg-white/5 px-2.5 py-1 rounded border border-white/10"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset Portal</span>
            </button>
          </div>
        </div>

        {/* HERO HEADER */}
        <header className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-tr from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/30 border border-white/20">
              <GraduationCap className="w-8 h-8 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
                  JEE Scholar
                </h1>
                <span className="bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 font-bold text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full shadow-[0_0_12px_rgba(52,211,153,0.4)]">
                  MAIN & ADVANCED
                </span>
              </div>
              <p className="text-xs md:text-sm text-slate-400 mt-1">
                Gamified tracker, interactive formula cards, and deep doubt resolution.
              </p>
            </div>
          </div>

          {/* Core progress circle */}
          <div className="flex items-center gap-3 bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl">
            <div className="relative w-10 h-10 rounded-full border-2 border-indigo-500/40 flex items-center justify-center">
              <span className="text-xs font-bold text-white">
                {Math.round((completedChaptersCount / (totalChaptersCount || 1)) * 100)}%
              </span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Overall Progress</span>
              <span className="text-xs font-semibold text-slate-200 block">
                {completedChaptersCount} of {totalChaptersCount} Chapters Done
              </span>
            </div>
          </div>
        </header>

        {/* SUBJECT SWITCHERS */}
        <section className="grid grid-cols-3 gap-3 md:max-w-2xl">
          <button
            id="subject-btn-physics"
            onClick={() => setSelectedSubject("physics")}
            className={`p-3.5 md:p-4 rounded-2xl border text-left transition duration-300 relative overflow-hidden flex items-center justify-between ${
              selectedSubject === "physics"
                ? "bg-cyan-500/20 backdrop-blur-md border-cyan-500/40 shadow-lg text-white"
                : "bg-white/5 backdrop-blur-md border-white/10 text-slate-400 hover:border-white/20 hover:text-white"
            }`}
          >
            <div>
              <span className="block text-[10px] font-bold uppercase tracking-wider opacity-60">Subject 01</span>
              <span className="font-extrabold text-sm md:text-base">Physics</span>
            </div>
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold ${
              selectedSubject === "physics" ? "bg-cyan-500/30 border-cyan-400/40 text-cyan-200" : "bg-white/5 border-white/10 text-slate-400"
            } border`}>
              Φ
            </div>
          </button>

          <button
            id="subject-btn-chemistry"
            onClick={() => setSelectedSubject("chemistry")}
            className={`p-3.5 md:p-4 rounded-2xl border text-left transition duration-300 relative overflow-hidden flex items-center justify-between ${
              selectedSubject === "chemistry"
                ? "bg-amber-500/20 backdrop-blur-md border-amber-500/40 shadow-lg text-white"
                : "bg-white/5 backdrop-blur-md border-white/10 text-slate-400 hover:border-white/20 hover:text-white"
            }`}
          >
            <div>
              <span className="block text-[10px] font-bold uppercase tracking-wider opacity-60">Subject 02</span>
              <span className="font-extrabold text-sm md:text-base">Chemistry</span>
            </div>
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold ${
              selectedSubject === "chemistry" ? "bg-amber-500/30 border-amber-400/40 text-amber-200" : "bg-white/5 border-white/10 text-slate-400"
            } border`}>
              Ω
            </div>
          </button>

          <button
            id="subject-btn-maths"
            onClick={() => setSelectedSubject("maths")}
            className={`p-3.5 md:p-4 rounded-2xl border text-left transition duration-300 relative overflow-hidden flex items-center justify-between ${
              selectedSubject === "maths"
                ? "bg-emerald-500/20 backdrop-blur-md border-emerald-500/40 shadow-lg text-white"
                : "bg-white/5 backdrop-blur-md border-white/10 text-slate-400 hover:border-white/20 hover:text-white"
            }`}
          >
            <div>
              <span className="block text-[10px] font-bold uppercase tracking-wider opacity-60">Subject 03</span>
              <span className="font-extrabold text-sm md:text-base">Maths</span>
            </div>
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold ${
              selectedSubject === "maths" ? "bg-emerald-500/30 border-emerald-400/40 text-emerald-200" : "bg-white/5 border-white/10 text-slate-400"
            } border`}>
              ∫
            </div>
          </button>
        </section>

        {/* TABS NAVIGATION */}
        <nav className="flex items-center gap-1 bg-white/5 backdrop-blur-md p-1.5 rounded-2xl border border-white/10 overflow-x-auto">
          <button
            id="tab-btn-syllabus"
            onClick={() => setActiveTab("syllabus")}
            className={`px-4 py-2.5 rounded-xl font-semibold text-xs md:text-sm whitespace-nowrap transition duration-200 flex items-center gap-2 ${
              activeTab === "syllabus"
                ? `bg-white/10 text-white border border-white/10 shadow`
                : "text-slate-400 hover:text-white"
            }`}
          >
            <CheckSquare className="w-4 h-4" />
            <span>Syllabus Tracker</span>
          </button>

          <button
            id="tab-btn-notes"
            onClick={() => setActiveTab("notes")}
            className={`px-4 py-2.5 rounded-xl font-semibold text-xs md:text-sm whitespace-nowrap transition duration-200 flex items-center gap-2 ${
              activeTab === "notes"
                ? `bg-white/10 text-white border border-white/10 shadow`
                : "text-slate-400 hover:text-white"
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Revision Notes</span>
          </button>

          <button
            id="tab-btn-test"
            onClick={() => setActiveTab("test")}
            className={`px-4 py-2.5 rounded-xl font-semibold text-xs md:text-sm whitespace-nowrap transition duration-200 flex items-center gap-2 ${
              activeTab === "test"
                ? `bg-white/10 text-white border border-white/10 shadow`
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>Practice Test</span>
          </button>

          <button
            id="tab-btn-doubt"
            onClick={() => setActiveTab("doubt")}
            className={`px-4 py-2.5 rounded-xl font-semibold text-xs md:text-sm whitespace-nowrap transition duration-200 flex items-center gap-2 ${
              activeTab === "doubt"
                ? `bg-white/10 text-white border border-white/10 shadow`
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Doubt Solver</span>
          </button>

          <button
            id="tab-btn-analytics"
            onClick={() => setActiveTab("analytics")}
            className={`px-4 py-2.5 rounded-xl font-semibold text-xs md:text-sm whitespace-nowrap transition duration-200 flex items-center gap-2 ${
              activeTab === "analytics"
                ? `bg-white/10 text-white border border-white/10 shadow`
                : "text-slate-400 hover:text-white"
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>My Analytics</span>
          </button>
        </nav>

        {/* PRIMARY DISPLAY VIEWPORT */}
        <main className={`p-1 animate-fadeIn`}>
          {activeTab === "syllabus" && (
            <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 flex flex-col gap-6 relative overflow-hidden">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                  <span>Syllabus Tracker</span>
                  <span className={`text-xs px-2.5 py-0.5 rounded-full border uppercase tracking-wider font-semibold ${activeTheme.pill}`}>
                    {selectedSubject}
                  </span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Check off chapters as you study to automatically update preparation indices.
                </p>
              </div>

              {/* Chapters list */}
              <div className="flex flex-col gap-4">
                {chapters
                  .filter((c) => c.subject === selectedSubject)
                  .map((chapter) => {
                    const statusConfig = {
                      "not-started": { label: "Not Started", color: "bg-white/5 border-white/10 text-slate-400" },
                      "in-progress": { label: "In Progress", color: "bg-amber-500/10 border-amber-500/20 text-amber-300" },
                      "notes-read": { label: "Notes Read", color: "bg-blue-500/10 border-blue-500/20 text-blue-300" },
                      "completed": { label: "Completed", color: "bg-cyan-500/10 border-cyan-500/20 text-cyan-300" },
                      "mastered": { label: "Mastered 🔥", color: "bg-emerald-500/10 border-emerald-500/20 text-emerald-300" },
                    };
                    const activeStatus = statusConfig[chapter.status] || statusConfig["not-started"];

                    return (
                      <div
                        key={chapter.id}
                        id={`ch-row-${chapter.id}`}
                        className="bg-white/5 border border-white/10 p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 transition duration-200 hover:bg-white/10 hover:border-white/20"
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold border shrink-0 ${activeTheme.pill}`}>
                            {chapter.id.toUpperCase()}
                          </div>
                          <div>
                            <h4 className="text-sm font-bold text-white">{chapter.name}</h4>
                            <div className="flex flex-wrap items-center gap-2 mt-1">
                              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${activeStatus.color}`}>
                                {activeStatus.label}
                              </span>
                              {chapter.bestScore !== undefined && (
                                <span className="text-[10px] text-emerald-300 font-semibold bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/20">
                                  Best Accuracy: {chapter.bestScore}%
                                </span>
                              )}
                              <span className="text-[10px] text-slate-400">
                                {chapter.questions.length} JEE problems
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Status controls */}
                        <div className="flex items-center gap-2 self-end md:self-center">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider hidden sm:inline">
                            Set Status
                          </span>
                          <div className="flex bg-white/5 border border-white/10 rounded-xl p-1 gap-1">
                            {(["not-started", "in-progress", "completed", "mastered"] as ProgressStatus[]).map((st) => (
                              <button
                                key={st}
                                id={`status-btn-${chapter.id}-${st}`}
                                onClick={() => handleStatusChange(chapter.id, st)}
                                className={`px-2.5 py-1.5 rounded-lg text-[10px] font-semibold transition ${
                                  chapter.status === st
                                    ? "bg-white/10 text-white border border-white/10"
                                    : "text-slate-400 hover:text-white"
                                }`}
                              >
                                {st.replace("-", " ").toUpperCase()}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          {activeTab === "notes" && (
            <RevisionNotes chapters={chapters} selectedSubject={selectedSubject} />
          )}

          {activeTab === "test" && (
            <PracticeTest
              chapters={chapters}
              selectedSubject={selectedSubject}
              onTestComplete={handleTestComplete}
            />
          )}

          {activeTab === "doubt" && (
            <DoubtSolver chapters={chapters} selectedSubject={selectedSubject} />
          )}

          {activeTab === "analytics" && (
            <AnalyticsDashboard chapters={chapters} />
          )}
        </main>
      </div>
    </div>
  );
}
